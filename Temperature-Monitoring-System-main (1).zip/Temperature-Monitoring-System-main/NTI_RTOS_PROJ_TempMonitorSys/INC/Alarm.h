/*
 * Alarm.h
 *
 *  Created on: Sep 17, 2023
 *      Author: Omar A.Qadir
 */

#ifndef INC_ALARM_H_
#define INC_ALARM_H_

// Alarm init function
void Alarm_init( void );

// Alarm main function
void ALarm_main( void* );

#endif /* INC_ALARM_H_ */
