/*
 * TempUpdate.h
 *
 *  Created on: Sep 17, 2023
 *      Author: Omar A.Qadir
 */

#ifndef INC_TEMPUPDATE_H_
#define INC_TEMPUPDATE_H_

// initiation function
void TempUpdate_init( void );

// main function
void TempUpdate_main( void* );

#endif /* INC_TEMPUPDATE_H_ */
